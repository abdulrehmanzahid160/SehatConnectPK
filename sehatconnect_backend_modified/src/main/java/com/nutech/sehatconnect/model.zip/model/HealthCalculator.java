package com.nutech.sehatconnect.model;

/**
 * 1. ABSTRACT BASE CLASS
 * This is the parent class for all calculators.
 * It uses encapsulation (private fields, public getters/setters)
 * and abstraction (abstract methods).
 */
public abstract class HealthCalculator {
    private String name;
    private String gender;
    private int age;

    // Encapsulation: getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getProfile() {
        return "Name: " + name + ", Age: " + age + ", Gender: " + gender;
    }

    // Abstract methods to be implemented by child classes (Polymorphism)
    public abstract double calculate();
    public abstract String getAdvice();
}
