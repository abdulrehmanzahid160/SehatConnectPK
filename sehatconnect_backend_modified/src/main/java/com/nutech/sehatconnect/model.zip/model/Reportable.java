package com.nutech.sehatconnect.model;

/**
 * Reportable — interface for any class that can produce a text report
 * and a filename for that report.
 *
 * OOP concept: Interface — defines a contract without implementation.
 * HealthReport implements this. Future report types (e.g. MedicineReport)
 * would implement it too, enabling polymorphic handling.
 */
public interface Reportable {

    /**
     * Build and return the full text content of the report.
     * @return formatted multi-line string ready to be written to disk
     */
    String buildReportText();

    /**
     * Return the filename the report should be saved as.
     * @return e.g. "report_Ali_Khan.txt"
     */
    String getReportFilename();
}
